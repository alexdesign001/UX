/* File main.c
 */

#include <tchar.h>
#include <windows.h>
#include <commctrl.h>

#include <string.h>
#include <stdio.h>

#include "custom.h"
#include "wheel.h"


static HINSTANCE hInstance;
static HWND hwndMain;       // Main window.
static HWND hwndCustom;     // Custom control window.


#define MAINWIN_PADDING    5


static LRESULT CALLBACK
MainWinProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    switch (uMsg) {
    case WM_SIZE:
        if(wParam != SIZE_MINIMIZED) {
            RECT rc = { 0, 0, LOWORD(lParam), HIWORD(lParam) };
            InflateRect(&rc, -MAINWIN_PADDING, -MAINWIN_PADDING);
            SetWindowPos(hwndCustom, NULL, rc.left, rc.top, rc.right - rc.left, rc.bottom - rc.top, SWP_NOZORDER);
        }
        break;

    case WM_CREATE:
        // Create the custom control:
        hwndCustom = CreateWindow(CUSTOM_WC, NULL, WS_VISIBLE | WS_CHILD | WS_TABSTOP, 0, 0, 0, 0, hwnd, (HMENU) 100, hInstance, 0);
        SendMessage(hwndCustom, WM_SETFONT, (WPARAM)GetStockObject(DEFAULT_GUI_FONT), MAKELPARAM(TRUE, 0));
        return 0;

    case WM_CLOSE:
        PostQuitMessage(0);
        return 0;
    }

    return DefWindowProc(hwnd, uMsg, wParam, lParam);
}

int APIENTRY
_tWinMain(HINSTANCE hInst, HINSTANCE hInstPrev, TCHAR* lpszCmdLine, int iCmdShow)
{
    WNDCLASS wc = { 0 };
    MSG msg;

    hInstance = hInst;

    InitCommonControls();
    CustomRegister(hInstance);
    WheelInitialize();

    wc.style = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc = MainWinProc;
    wc.hInstance = hInstance;
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)(COLOR_BTNFACE + 1);
    wc.lpszClassName = _T("main_win");
    RegisterClass(&wc);

    hwndMain = CreateWindow(_T("main_win"), _T("Scrolling Demo"),
        WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT, 300, 350,
        NULL, NULL, hInstance, NULL);
    ShowWindow(hwndMain, iCmdShow);

    while (GetMessage(&msg, NULL, 0, 0)) {
        if (IsDialogMessage(hwndMain, &msg))
            continue;

        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    CustomUnregister();
    WheelUninitialize();
        
    return (int)msg.wParam;
}
