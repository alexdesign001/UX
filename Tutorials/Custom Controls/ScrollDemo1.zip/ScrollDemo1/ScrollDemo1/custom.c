/* File custom.c
 * (custom control implementation)
 */

#include "custom.h"
#include "wheel.h"


// Dummy contents for the control.
static const TCHAR* lpszLines[] = {
    _T("Line 1"),
    _T("Line 2"),
    _T("Line 3"),
    _T("Line 4"),
    _T("Line 5"),
    _T("Line 6"),
    _T("Line 7"),
    _T("Line 8"),
    _T("Line 9"),
    _T("Line 10"),
    _T("Line 11"),
    _T("Line 12"),
    _T("Line 13"),
    _T("Line 14"),
    _T("Line 15"),
    _T("Line 16"),
    _T("Line 17"),
    _T("Line 18"),
    _T("Line 19"),
    _T("Line 20"),
    _T("Line 21"),
    _T("Line 22"),
    _T("Line 23"),
    _T("Line 24"),
    _T("Line 25"),
    _T("Line 26"),
    _T("Line 27"),
    _T("Line 28"),
    _T("Line 29"),
    _T("Line 30"),
    _T("Line 31"),
    _T("Line 32"),
    _T("Line 33"),
    _T("Line 34"),
    _T("Line 25"),
    _T("Line 36"),
    _T("Line 37"),
    _T("Line 38"),
    _T("Line 39"),
    _T("Line 40")
};

static const int nLines = (sizeof(lpszLines) / sizeof(lpszLines[0]));


// Data of the custom control.
typedef struct CustomData {
    HWND hwnd;
    HFONT hFont;
    UINT cyFont;
} CustomData;


// Handle WM_PAINT message.
static void
CustomPaint(CustomData* pData, HDC hDC, RECT* prcDirty, BOOL bErase)
{
    int i;
    int y = 0;

    if (bErase)
        FillRect(hDC, prcDirty, GetStockObject(WHITE_BRUSH));

    if (pData->hFont != NULL)
        SelectObject(hDC, pData->hFont);

    SetTextColor(hDC, RGB(0, 0, 0));
    SetBkMode(hDC, TRANSPARENT);

    for (i = GetScrollPos(pData->hwnd, SB_VERT); i < nLines; i++) {
        TextOut(hDC, 0, y, lpszLines[i], _tcslen(lpszLines[i]));
        y += pData->cyFont;
    }
}

// Perform the scrolling to the new location.
// (Ensures the newPos is in the allowed range between nMin and nMax so all 
// callers can be simplified in this regard.)
static void
CustomSetVScrollPos(CustomData* pData, int nPos)
{
    int nOldPos;

    nOldPos = GetScrollPos(pData->hwnd, SB_VERT);

    // Setup and refresh the toolbar:
    SetScrollPos(pData->hwnd, SB_VERT, nPos, TRUE);

    // Ensure the new pos is in the allowed range (between nin and nMax):
    nPos = GetScrollPos(pData->hwnd, SB_VERT);

    // Refresh client area:
    ScrollWindowEx(pData->hwnd, 0, (nOldPos - nPos) * pData->cyFont,
        NULL, NULL, NULL, NULL, SW_ERASE | SW_INVALIDATE);
}

// Lets distinguish "real nPage" and logiucal "nPage". 
// The former is the value descrbing the state of scrollbar and
// stored internally. We can get it with GetScrollInfo().
//
// The latter is how much we really want to scroll when scrolling
// up or down for a page.
static int
CustomLogicalPage(int nPage)
{
    if (nPage > 3) {
        // For larger pages, it is better if there is a little overlap
        // so user does not get lost.
        return nPage - 1;
    }

    if (nPage < 1) {
        // Even if control is so low it does not even have space for 
        // a single line, we still want to make scroll at least a little.
        return 1;
    }

    // In other cases, lets respect the real value.
    return nPage;
}

// Handles WM_VSCROLL message.
static void
CustomVScroll(CustomData* pData, int iWhat)
{
    int nPos;
    SCROLLINFO si;

    si.cbSize = sizeof(SCROLLINFO);
    si.fMask = SIF_RANGE | SIF_PAGE | SIF_POS | SIF_TRACKPOS;
    GetScrollInfo(pData->hwnd, SB_VERT, &si);

    switch (iWhat) {
    case SB_TOP:            nPos = si.nMin; break;
    case SB_BOTTOM:         nPos = si.nMax; break;
    case SB_LINEUP:         nPos = si.nPos - 1; break;
    case SB_LINEDOWN:       nPos = si.nPos + 1; break;
    case SB_PAGEUP:         nPos = si.nPos - CustomLogicalPage(si.nPage); break;
    case SB_PAGEDOWN:       nPos = si.nPos + CustomLogicalPage(si.nPage); break;
    case SB_THUMBTRACK:     nPos = si.nTrackPos; break;
    default:
    case SB_THUMBPOSITION:  nPos = si.nPos; break;
    }

    CustomSetVScrollPos(pData, nPos);
}

// Handle WM_KEYDOWN message.
static void
CustomKeyDown(CustomData* pData, UINT vkCode)
{
    switch (vkCode) {
    case VK_HOME:   CustomVScroll(pData, SB_TOP); break;
    case VK_END:    CustomVScroll(pData, SB_BOTTOM); break;
    case VK_UP:     CustomVScroll(pData, SB_LINEUP); break;
    case VK_DOWN:   CustomVScroll(pData, SB_LINEDOWN); break;
    case VK_PRIOR:  CustomVScroll(pData, SB_PAGEUP); break;
    case VK_NEXT:   CustomVScroll(pData, SB_PAGEDOWN); break;
    }
}

// Handle WM_MOUSEWHEEL message.
static void
CustomMouseWheel(CustomData* pData, int iDelta)
{
    SCROLLINFO si;
    int iLines;

    si.cbSize = sizeof(SCROLLINFO);
    si.fMask = SIF_PAGE | SIF_POS;
    GetScrollInfo(pData->hwnd, SB_VERT, &si);

    // Compute how many lines to scroll.
    iLines = WheelScrollLines(pData->hwnd, iDelta,
                              CustomLogicalPage(si.nPage), TRUE);

    // Scroll to the desired location.
    CustomSetVScrollPos(pData, si.nPos + iLines);
}

// Control window procedure.
static LRESULT CALLBACK
CustomProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    CustomData* pData = (CustomData*) GetWindowLongPtr(hwnd, 0);

    switch(uMsg) {
        case WM_ERASEBKGND:
            return FALSE;  // Defer erasing into WM_PAINT

        case WM_PAINT:
        {
            PAINTSTRUCT ps;
            BeginPaint(hwnd, &ps);
            CustomPaint(pData, ps.hdc, &ps.rcPaint, ps.fErase);
            EndPaint(hwnd, &ps);
            return 0;
        }

        case WM_PRINTCLIENT:
        {
            RECT rc;
            GetClientRect(hwnd, &rc);
            CustomPaint(pData, (HDC) wParam, &rc, TRUE);
            return 0;
        }

        case WM_KEYDOWN:
            CustomKeyDown(pData, wParam);
            return 0;

        case WM_GETDLGCODE:
            return DLGC_WANTALLKEYS;

        case WM_VSCROLL:
            CustomVScroll(pData, LOWORD(wParam));
            return 0;

        case WM_MOUSEWHEEL:
            CustomMouseWheel(pData, (SHORT) HIWORD(wParam));
            return 0;

        case WM_SIZE:
        {
            SCROLLINFO si;

            // We need to update scrolling page to correspond to the current control height.
            si.cbSize = sizeof(SCROLLINFO);
            si.fMask = SIF_PAGE;
            si.nPage = (HIWORD(lParam) / pData->cyFont);
            SetScrollInfo(hwnd, SB_VERT, &si, TRUE);
            break;
        }

        case WM_SETFONT:
        {
            HDC hDC;
            HFONT hFontOld;
            TEXTMETRIC tm;
            
            pData->hFont = (HFONT)wParam;

            // Remember height of the HFONT:
            hDC = GetDC(NULL);
            hFontOld = SelectObject(hDC, (pData->hFont != NULL ? pData->hFont : GetStockObject(SYSTEM_FONT)));
            GetTextMetrics(hDC, &tm);
            SelectObject(hDC, hFontOld);
            pData->cyFont = tm.tmHeight;

            if (lParam)
                InvalidateRect(hwnd, NULL, TRUE);
            break;
        }

        case WM_CREATE:
            // Set scrolling range. As we have immutable data contents and the scrolling unit is
            // a text line, we never ned to change it.
            SetScrollRange(hwnd, SB_VERT, 0, nLines - 1, FALSE);
            break;

        case WM_NCCREATE:
            pData = (CustomData*) malloc(sizeof(CustomData));
            if(pData == NULL)
                return FALSE;
            SetWindowLongPtr(hwnd, 0, (LONG_PTR)pData);
            pData->hwnd = hwnd;

            // Ensure we have initialized pData->hFont and ->cyFont.
            SendMessage(hwnd, WM_SETFONT, 0, 0);
            return TRUE;

        case WM_NCDESTROY:
            if(pData != NULL)
                free(pData);
            return 0;
    }
    return DefWindowProc(hwnd, uMsg, wParam, lParam);
}

void
CustomRegister(HINSTANCE hInstance)
{
    WNDCLASS wc = { 0 };

    wc.hInstance = hInstance;
    wc.lpfnWndProc = CustomProc;
    wc.cbWndExtra = sizeof(CustomData*);
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.lpszClassName = CUSTOM_WC;
    RegisterClass(&wc);
}

void
CustomUnregister(void)
{
    UnregisterClass(CUSTOM_WC, NULL);
}
