/* File main.c
 * (application code)
 */

#include <tchar.h>
#include <windows.h>
#include <commctrl.h>

#include <string.h>
#include <stdio.h>


#define ID_LISTVIEW  1000

static HINSTANCE hInstance;
static HWND hwndMain;
static HWND hwndListView;


static const struct {
    TCHAR* pszText;
    int cx;
} columnMap[] = {
    { _T("Task"),     150 },
    { _T("Priority"),  60 },
    { _T("Progress"), 120 },
    { 0 }
};

static const struct {
    TCHAR* pszName;
    TCHAR* pszPriority;
    int iProgress;
} taskMap[] = {
    { _T("Fix bug #237"),         _T("High"),   15 },
    { _T("Write user manual"),    _T("Normal"), 80 },
    { _T("Test performance"),     _T("Low"),     5 },
	{ _T("Fix bug #239"),         _T("Done"),  100 },
    { _T("Prepare presentation"), _T("High"),   90 },
    { 0 }
};


static void
PopulateListView(void)
{
    LVCOLUMN col;
    LVITEM item;
    TCHAR pszBuffer[16];
    int i;

    col.mask = LVCF_WIDTH | LVCF_TEXT;
    for(i = 0; columnMap[i].pszText != NULL; i++) {
        col.pszText = columnMap[i].pszText;
        col.cx = columnMap[i].cx;
        SendMessage(hwndListView, LVM_INSERTCOLUMN, i, (LPARAM) &col);
    }

    for(i = 0; taskMap[i].pszName != NULL; i++) {
        item.mask = LVIF_PARAM | LVIF_TEXT;
        item.iItem = i;
        item.iSubItem = 0;
        item.pszText = taskMap[i].pszName;
        item.lParam = taskMap[i].iProgress;
        SendMessage(hwndListView, LVM_INSERTITEM, 0, (LPARAM) &item);

        item.mask = LVIF_TEXT;
        item.iSubItem = 1;
        item.pszText = taskMap[i].pszPriority;
        SendMessage(hwndListView, LVM_SETITEM, 0, (LPARAM) &item);

        item.iSubItem = 2;
        item.pszText = pszBuffer;
        _stprintf(pszBuffer, _T("%d %%"), taskMap[i].iProgress);
        SendMessage(hwndListView, LVM_SETITEM, 0, (LPARAM) &item);
    }
}

static LRESULT
HandleCustomDraw(NMLVCUSTOMDRAW* pcd)
{
	TCHAR buffer[16];
	LVITEM item;

    switch(pcd->nmcd.dwDrawStage) {
        case CDDS_PREPAINT:
            /* Tell the control we are interested in per-item notifications.
             * (We need it just to tell the control we want per-subitem
             * notifications.) */
            return CDRF_DODEFAULT | CDRF_NOTIFYITEMDRAW;

        case (CDDS_ITEM | CDDS_PREPAINT):
            /* Tell the control we are interested in per-subitem notifications. */
            return CDRF_DODEFAULT | CDRF_NOTIFYSUBITEMDRAW;

        case (CDDS_ITEM | CDDS_SUBITEM | CDDS_PREPAINT):
            switch(pcd->iSubItem) {
                case 1:
                    /* Customize "priority" column by marking some priority levels
                     * with appropriate color. */
                    item.iSubItem = pcd->iSubItem;
                    item.pszText = buffer;
                    item.cchTextMax = sizeof(buffer) / sizeof(buffer[0]);
                    SendMessage(hwndListView, LVM_GETITEMTEXT, pcd->nmcd.dwItemSpec, (LPARAM) &item);
                    if(_tcsicmp(_T("High"), buffer) == 0)
                        pcd->clrText = RGB(190,0,0);
					else if(_tcsicmp(_T("Done"), buffer) == 0)
						pcd->clrText = RGB(0,160,0);
                    /* Let the control do the painting itself with the new color. */
                    return CDRF_DODEFAULT;

                case 2:
                {
                    /* Customize "progress" column. We paint simple progress
                     * indicator. */
                    int iProgress = pcd->nmcd.lItemlParam;
                    int cx;
                    HDC hdc = pcd->nmcd.hdc;
					COLORREF clrBack;
                    HBRUSH hBackBrush;
                    HBRUSH hProgressBrush;
                    HBRUSH hOldBrush;
					HPEN hPen;
					HPEN hOldPen;
                    RECT rc;

					clrBack = pcd->clrTextBk;
					if(clrBack == CLR_NONE || clrBack == CLR_DEFAULT)
						clrBack = RGB(255,255,255);

                    hBackBrush = CreateSolidBrush(clrBack);
                    hProgressBrush = CreateSolidBrush(RGB(190,190,255));
					hPen = CreatePen(PS_SOLID, 0, RGB(190,190,255));

                    hOldBrush = (HBRUSH) SelectObject(hdc, hBackBrush);
                    FillRect(hdc, &pcd->nmcd.rc, hBackBrush);

                    cx = pcd->nmcd.rc.right - pcd->nmcd.rc.left - 6;
                    if(cx < 0)
                        cx = 0;
                    rc.left = pcd->nmcd.rc.left + 3;
                    rc.top = pcd->nmcd.rc.top + 2;
                    rc.right = rc.left + cx * iProgress / 100;
                    rc.bottom = pcd->nmcd.rc.bottom - 2;
                    SelectObject(hdc, hProgressBrush);
                    FillRect(hdc, &rc, hProgressBrush);

					rc.right = pcd->nmcd.rc.right - 3;
					SelectObject(hdc, GetStockObject(HOLLOW_BRUSH));
					hOldPen = SelectObject(hdc, hPen);
					Rectangle(hdc, rc.left, rc.top, rc.right, rc.bottom);

                    item.iSubItem = pcd->iSubItem;
                    item.pszText = buffer;
                    item.cchTextMax = sizeof(buffer) / sizeof(buffer[0]);
                    SendMessage(hwndListView, LVM_GETITEMTEXT, pcd->nmcd.dwItemSpec, (LPARAM) &item);
					DrawText(hdc, buffer, -1, &rc, 
							DT_CENTER | DT_VCENTER | DT_NOPREFIX | DT_SINGLELINE | DT_END_ELLIPSIS);

                    SelectObject(hdc, hOldBrush);
                    DeleteObject(hProgressBrush);
                    DeleteObject(hBackBrush);
					SelectObject(hdc, hOldPen);
					DeleteObject(hPen);

                    /* Tell the control to not paint as we did so. */
                    return CDRF_SKIPDEFAULT;
                }
            }
            break;
    }

    /* For all unhandled cases, we let the control do the default. */
    return CDRF_DODEFAULT;
}

static LRESULT CALLBACK
MainWinProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    switch(uMsg) {
        case WM_NOTIFY:
        {
            NMHDR* pHdr = (NMHDR*) lParam;
            if(pHdr->idFrom == ID_LISTVIEW  &&  pHdr->code == NM_CUSTOMDRAW)
                return HandleCustomDraw((NMLVCUSTOMDRAW*) pHdr);
            break;
        }

        case WM_SIZE:
            if(wParam != SIZE_MAXHIDE  &&
               wParam != SIZE_MAXSHOW  &&
               wParam != SIZE_MINIMIZED) {
                SetWindowPos(hwndListView, NULL, 10, 10, LOWORD(lParam) - 20,
                        HIWORD(lParam) - 20, SWP_NOZORDER);
            }
            break;

        case WM_CREATE:
            hwndListView = CreateWindow(WC_LISTVIEW, NULL,
                    LVS_REPORT | WS_TABSTOP | WS_BORDER | WS_CHILD | WS_VISIBLE,
                    0, 0, 0, 0, hwnd, (HMENU) ID_LISTVIEW, hInstance, 0);
            PopulateListView();
            return 0;

        case WM_CLOSE:
            PostQuitMessage(0);
            return 0;
    }

    return DefWindowProc(hwnd, uMsg, wParam, lParam);
}

int APIENTRY
_tWinMain(HINSTANCE hInst, HINSTANCE hInstPrev, TCHAR* lpszCmdLine, int iCmdShow)
{
    WNDCLASS wc = { 0 };
    MSG msg;

    hInstance = hInst;
    InitCommonControls();

    wc.style = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc = MainWinProc;
    wc.hInstance = hInstance;
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)(COLOR_BTNFACE + 1);
    wc.lpszClassName = _T("main_win");
    RegisterClass(&wc);

    hwndMain = CreateWindow(_T("main_win"), _T("Custom Draw Demo"),
                WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT, 500, 350,
                NULL, NULL, hInstance, NULL);
    ShowWindow(hwndMain, iCmdShow);

    while(GetMessage(&msg, NULL, 0, 0)) {
        if(IsDialogMessage(hwndMain, &msg))
            continue;

        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    return (int) msg.wParam;
}
