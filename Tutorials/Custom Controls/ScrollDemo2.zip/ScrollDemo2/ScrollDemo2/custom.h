/* File custom.h
 * (custom control interface)
 */

#ifndef CUSTOM_H
#define CUSTOM_H

#include <tchar.h>
#include <windows.h>


// Window class:
#define CUSTOM_WC              _T("CustomControl")

// Message to set column range.
// WPARAM: Min. column index
// LPARAM: Max. column index
// Returns TRUE on success.
#define XXM_SETCOLRANGE       (WM_USER + 100)

// Message to set row range.
// WPARAM: Min. row index
// LPARAM: Max. row index
// Returns TRUE on success.
#define XXM_SETROWRANGE       (WM_USER + 101)

// Register/unregister the window class:
void CustomRegister(HINSTANCE hInstance);
void CustomUnregister(void);


#endif  /* CUSTOM_H */
