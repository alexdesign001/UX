/* File main.c
 */

#include <tchar.h>
#include <windows.h>
#include <commctrl.h>

#include <string.h>
#include <stdio.h>

#include "custom.h"
#include "wheel.h"


static HINSTANCE hInstance;
static HWND hwndMain;       // Main window.
static HWND hwndCustom;     // Custom control window.

// Edit and up/dopwn controls for setting nMin and nMax, both for horizontal
// and vertical scrollbars of the custom controls:
static HWND hwndEditMinHorz;
static HWND hwndUpDownMinHorz;
static HWND hwndEditMaxHorz;
static HWND hwndUpDownMaxHorz;
static HWND hwndEditMinVert;
static HWND hwndUpDownMinVert;
static HWND hwndEditMaxVert;
static HWND hwndUpDownMaxVert;


#define MAINWIN_PADDING      5

static BOOL CALLBACK
SetChildFont(HWND hwndChild, LPARAM lParam)
{
    HFONT hFont = (HFONT)lParam;
    SendMessage(hwndChild, WM_SETFONT, (WPARAM)hFont, MAKELPARAM(TRUE, 0));
    return TRUE;
}

static LRESULT CALLBACK
MainWinProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    switch (uMsg) {
    case WM_SIZE:
        if (wParam != SIZE_MINIMIZED) {
            RECT rc = { 0, 0, LOWORD(lParam), HIWORD(lParam) };
            InflateRect(&rc, -MAINWIN_PADDING, -MAINWIN_PADDING);
            SetWindowPos(hwndCustom, NULL, rc.left, rc.top + 70, rc.right - rc.left, rc.bottom - rc.top - 70, SWP_NOZORDER);
        }
        break;

    case WM_COMMAND:
        // On edit control update, propagate the hrozintal/vertical range into
        // the custom control:
        if (HIWORD(wParam)) {
            HWND hwndControl = (HWND)lParam;
            if (hwndControl == hwndEditMinHorz || hwndControl == hwndEditMaxHorz) {
                int nMin = GetDlgItemInt(hwnd, GetWindowLong(hwndEditMinHorz, GWL_ID), NULL, TRUE);
                int nMax = GetDlgItemInt(hwnd, GetWindowLong(hwndEditMaxHorz, GWL_ID), NULL, TRUE);
                SendMessage(hwndCustom, XXM_SETCOLRANGE, (WPARAM)nMin, (LPARAM)nMax);
            } else if (hwndControl == hwndEditMinVert || hwndControl == hwndEditMaxVert) {
                int nMin = GetDlgItemInt(hwnd, GetWindowLong(hwndEditMinVert, GWL_ID), NULL, TRUE);
                int nMax = GetDlgItemInt(hwnd, GetWindowLong(hwndEditMaxVert, GWL_ID), NULL, TRUE);
                SendMessage(hwndCustom, XXM_SETROWRANGE, (WPARAM)nMin, (LPARAM)nMax);
            }
        }
        break;

    case WM_CREATE:
        // Create the auxiliary controls:
        CreateWindow(_T("STATIC"), _T("Horizontal range:"), WS_VISIBLE | WS_CHILD | SS_LEFT, 10, 12, 100, 20, hwnd, (HMENU)-1, NULL, 0);
        hwndEditMinHorz = CreateWindowEx(WS_EX_CLIENTEDGE, _T("EDIT"), NULL, WS_VISIBLE | WS_CHILD | WS_TABSTOP | ES_RIGHT | ES_NUMBER, 100, 10, 50, 22, hwnd, (HMENU)210, NULL, 0);
        hwndUpDownMinHorz = CreateWindow(UPDOWN_CLASS, NULL, WS_VISIBLE | WS_CHILD | UDS_AUTOBUDDY | UDS_SETBUDDYINT | UDS_ALIGNRIGHT | UDS_ARROWKEYS | UDS_HOTTRACK, 0, 0, 0, 0, hwnd, (HMENU)211, NULL, 0);
        hwndEditMaxHorz = CreateWindowEx(WS_EX_CLIENTEDGE, _T("EDIT"), NULL, WS_VISIBLE | WS_CHILD | WS_TABSTOP | ES_RIGHT | ES_NUMBER, 155, 10, 50, 22, hwnd, (HMENU)220, NULL, 0);
        hwndUpDownMaxHorz = CreateWindow(UPDOWN_CLASS, NULL, WS_VISIBLE | WS_CHILD | UDS_AUTOBUDDY | UDS_SETBUDDYINT | UDS_ALIGNRIGHT | UDS_ARROWKEYS | UDS_HOTTRACK, 0, 0, 0, 0, hwnd, (HMENU)221, NULL, 0);
        CreateWindow(_T("STATIC"), _T("Vertical range:"), WS_VISIBLE | WS_CHILD | SS_LEFT, 10, 39, 100, 20, hwnd, (HMENU)-1, NULL, 0);
        hwndEditMinVert = CreateWindowEx(WS_EX_CLIENTEDGE, _T("EDIT"), NULL, WS_VISIBLE | WS_CHILD | WS_TABSTOP | ES_RIGHT | ES_NUMBER, 100, 37, 50, 22, hwnd, (HMENU)230, NULL, 0);
        hwndUpDownMinVert = CreateWindow(UPDOWN_CLASS, NULL, WS_VISIBLE | WS_CHILD | UDS_AUTOBUDDY | UDS_SETBUDDYINT | UDS_ALIGNRIGHT | UDS_ARROWKEYS | UDS_HOTTRACK, 0, 0, 0, 0, hwnd, (HMENU)231, NULL, 0);
        hwndEditMaxVert = CreateWindowEx(WS_EX_CLIENTEDGE, _T("EDIT"), NULL, WS_VISIBLE | WS_CHILD | WS_TABSTOP | ES_RIGHT | ES_NUMBER, 155, 37, 50, 22, hwnd, (HMENU)240, NULL, 0);
        hwndUpDownMaxVert = CreateWindow(UPDOWN_CLASS, NULL, WS_VISIBLE | WS_CHILD | UDS_AUTOBUDDY | UDS_SETBUDDYINT | UDS_ALIGNRIGHT | UDS_ARROWKEYS | UDS_HOTTRACK, 0, 0, 0, 0, hwnd, (HMENU)241, NULL, 0);

        // To simplify the demo app, we "enforce" the natural condition
        // nMin < nMax only by allowed ranges for the up/down controls:
        SendMessage(hwndUpDownMinHorz, UDM_SETRANGE32, (WPARAM)-10, (LPARAM)0);
        SendMessage(hwndUpDownMinHorz, UDM_SETPOS32, 0, 0);
        SendMessage(hwndUpDownMaxHorz, UDM_SETRANGE32, (WPARAM)+5, (LPARAM)+10);
        SendMessage(hwndUpDownMaxHorz, UDM_SETPOS32, 0, 5);
        SendMessage(hwndUpDownMinVert, UDM_SETRANGE32, (WPARAM)-10, (LPARAM)0);
        SendMessage(hwndUpDownMinVert, UDM_SETPOS32, 0, 0);
        SendMessage(hwndUpDownMaxVert, UDM_SETRANGE32, (WPARAM)-5, (LPARAM)+10);
        SendMessage(hwndUpDownMaxVert, UDM_SETPOS32, 0, 5);

        // Create the custom control:
        hwndCustom = CreateWindow(CUSTOM_WC, NULL, WS_VISIBLE | WS_CHILD | WS_TABSTOP | WS_BORDER, 0, 0, 0, 0, hwnd, (HMENU)250, hInstance, 0);

        // Set font for all child controls:
        EnumChildWindows(hwnd, SetChildFont, (LPARAM)GetStockObject(DEFAULT_GUI_FONT));
        return 0;

    case WM_CLOSE:
        PostQuitMessage(0);
        return 0;
    }

    return DefWindowProc(hwnd, uMsg, wParam, lParam);
}

int APIENTRY
_tWinMain(HINSTANCE hInst, HINSTANCE hInstPrev, TCHAR* lpszCmdLine, int iCmdShow)
{
    INITCOMMONCONTROLSEX icce = { sizeof(INITCOMMONCONTROLSEX), ICC_UPDOWN_CLASS };
    WNDCLASS wc = { 0 };
    MSG msg;

    hInstance = hInst;

    InitCommonControlsEx(&icce);
    CustomRegister(hInstance);
    WheelInitialize();

    wc.style = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc = MainWinProc;
    wc.hInstance = hInstance;
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)(COLOR_BTNFACE + 1);
    wc.lpszClassName = _T("main_win");
    RegisterClass(&wc);

    hwndMain = CreateWindow(_T("main_win"), _T("Scrolling Demo"),
        WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT, 300, 350,
        NULL, NULL, hInstance, NULL);
    ShowWindow(hwndMain, iCmdShow);

    while (GetMessage(&msg, NULL, 0, 0)) {
        if (IsDialogMessage(hwndMain, &msg))
            continue;

        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    CustomUnregister();
    WheelUninitialize();
        
    return (int)msg.wParam;
}
