/* File custom.c
 * (custom control implementation)
 */

#include "custom.h"
#include "wheel.h"


#ifndef MAX
#define MAX(a,b)    ((a) > (b) ? (a) : (b))
#endif



// Cell width and height.
#define CELL_CX          80
#define CELL_CY          80

// Row header width and column header height.
#define HEADER_CX        60
#define HEADER_CY        60

// Scroll unit, horizontal and vertical.
#define SCROLL_CX        10
#define SCROLL_CY        10

// We scroll in tens of pixels.
#define SCROLL_STEP      10

// Cell colors.
#define HEADER_TEXT_COLOR       RGB(255,255,255)
#define HEADER_BACK_COLOR       RGB(0,0,0)
#define NORMAL_TEXT_COLOR       RGB(0,0,0)
#define NORMAL_BACK_COLOR_A     RGB(159,159,223)
#define NORMAL_BACK_COLOR_B     RGB(191,191,255)


// Data of the custom control.
typedef struct CustomData {
    HWND hwnd;
    HFONT hFont;
    int colMin;
    int colMax;
    int rowMin;
    int rowMax;
} CustomData;


static void
CustomSetScrollbarRange(CustomData* pData, int scrollbarId, int indexMin, int indexMax)
{
    SCROLLINFO si;

    si.cbSize = sizeof(SCROLLINFO);
    si.fMask = SIF_RANGE;
    si.nMin = indexMin * CELL_CX;
    si.nMax = (indexMax+1) * CELL_CX;
    SetScrollInfo(pData->hwnd, scrollbarId, &si, TRUE);
}

// Handle XXM_SETCOLRANGE:
static BOOL
CustomSetColRange(CustomData* pData, int colMin, int colMax)
{
    if (colMin >= colMax)
        return FALSE;
    pData->colMin = colMin;
    pData->colMax = colMax;
    CustomSetScrollbarRange(pData, SB_HORZ, colMin, colMax);
    InvalidateRect(pData->hwnd, NULL, TRUE);
    return TRUE;
}

// Handle XXM_SETROWRANGE:
static BOOL
CustomSetRowRange(CustomData* pData, int rowMin, int rowMax)
{
    if (rowMin >= rowMax)
        return FALSE;
    pData->rowMin = rowMin;
    pData->rowMax = rowMax;
    CustomSetScrollbarRange(pData, SB_VERT, rowMin, rowMax);
    InvalidateRect(pData->hwnd, NULL, TRUE);
    return TRUE;
}

// Handle WM_SIZE:
static void
CustomSize(CustomData* pData, UINT uWidth, UINT uHeight)
{
    RECT rcClient;
    SCROLLINFO si;

    // Note the page is computed so that it reserves some space for column
    // and row headers in the client area.

    si.cbSize = sizeof(SCROLLINFO);
    si.fMask = SIF_PAGE;
    si.nPage = (uWidth > HEADER_CX ? uWidth - HEADER_CX : 0);
    SetScrollInfo(pData->hwnd, SB_HORZ, &si, TRUE);

    // The above may change client area size, so ask for it.
    GetClientRect(pData->hwnd, &rcClient);
    uHeight = rcClient.bottom - rcClient.top;

    si.nPage = (uHeight > HEADER_CY ? uHeight - HEADER_CY : 0);
    SetScrollInfo(pData->hwnd, SB_VERT, &si, TRUE);
}

static void
CustomPaintCell(HDC hDC, const TCHAR* lpszText, RECT* lpRect, HBRUSH hBackBrush)
{
    FillRect(hDC, lpRect, hBackBrush);

    if (lpszText != NULL)
        DrawText(hDC, lpszText, -1, lpRect, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
}

static void
CustomSetClip(HDC hDC, RECT* prcClip)
{
    HRGN hrgnClip;
    
    hrgnClip = CreateRectRgn(prcClip->left, prcClip->top, prcClip->right, prcClip->bottom);
    SelectClipRgn(hDC, hrgnClip);
    DeleteObject(hrgnClip);
}

// Handle WM_PAINT message.
static void
CustomPaint(CustomData* pData, HDC hDC, RECT* prcDirty, BOOL bErase)
{
    int nPosHorz;
    int nPosVert;
    RECT rcDirtyBody;
    int col, colMin, colMax;
    int row, rowMin, rowMax;
    HBRUSH hHeaderBrush;
    HBRUSH hNormalBrushA;
    HBRUSH hNormalBrushB;
    
    // Get scrollbar postions:
    nPosHorz = GetScrollPos(pData->hwnd, SB_HORZ);
    nPosVert = GetScrollPos(pData->hwnd, SB_VERT);

    // Part of the dirty rect intersecting the body of the control 
    // (i.e. exclude headers):
    rcDirtyBody.left = MAX(prcDirty->left, HEADER_CX);
    rcDirtyBody.top = MAX(prcDirty->top, HEADER_CY);
    rcDirtyBody.right = prcDirty->right;
    rcDirtyBody.bottom = prcDirty->bottom;

    // Often, we don't need to paint everything, so lets get column and row
    // ranges which intersect the dirty rectangle.
    colMin = (rcDirtyBody.left - HEADER_CX + nPosHorz - (CELL_CX-1)) / CELL_CX;
    colMax = (rcDirtyBody.right - HEADER_CX + nPosHorz + (CELL_CX - 1)) / CELL_CX;
    if (colMax > pData->colMax)
        colMax = pData->colMax;

    rowMin = (rcDirtyBody.top - HEADER_CY + nPosVert - (CELL_CY - 1)) / CELL_CY;
    rowMax = (rcDirtyBody.bottom - HEADER_CY + nPosVert + (CELL_CY - 1)) / CELL_CY;
    if (rowMax > pData->rowMax)
        rowMax = pData->rowMax;

    if (pData->hFont != NULL)
        SelectObject(hDC, pData->hFont);
    SetBkMode(hDC, TRANSPARENT);
    SetTextColor(hDC, HEADER_TEXT_COLOR);

    hHeaderBrush = CreateSolidBrush(HEADER_BACK_COLOR);
    hNormalBrushA = CreateSolidBrush(NORMAL_BACK_COLOR_A);
    hNormalBrushB = CreateSolidBrush(NORMAL_BACK_COLOR_B);

    // Erase any background not covered with any cells:
    if (bErase) {
        int maxX = HEADER_CX + (pData->colMax - pData->colMin + 1) * CELL_CX;
        int maxY = HEADER_CY + (pData->rowMax - pData->rowMin + 1) * CELL_CY;
        HBRUSH hBackbrush = GetStockObject(WHITE_BRUSH);

        if (maxX < prcDirty->right) {
            RECT rc = { maxX, prcDirty->top, prcDirty->right, maxY };
            FillRect(hDC, &rc, hBackbrush);
        }

        if (maxY < prcDirty->bottom) {
            RECT rc = { prcDirty->left, maxY, prcDirty->right, prcDirty->bottom };
            FillRect(hDC, &rc, hBackbrush);
        }
    }

    if (prcDirty->top < CELL_CY  &&  prcDirty->left < CELL_CX) {
        RECT rc = { 0, 0, HEADER_CX, HEADER_CY };
        CustomPaintCell(hDC, NULL, &rc, hHeaderBrush);
    }

    // Paint column headers:
    if (prcDirty->top < CELL_CY) {
        RECT rcClip = { HEADER_CX, 0, rcDirtyBody.right, HEADER_CY };
        CustomSetClip(hDC, &rcClip);

        for (col = colMin; col <= colMax; col++) {
            RECT rc;
            TCHAR pszBuffer[32];

            rc.left = HEADER_CX + col * CELL_CX - nPosHorz;
            rc.top = 0;
            rc.right = rc.left + CELL_CX;
            rc.bottom = HEADER_CY;
            _sntprintf_s(pszBuffer, 32, _TRUNCATE, _T("Column %d"), col);
            CustomPaintCell(hDC, pszBuffer, &rc, hHeaderBrush);
        }
    }

    // Paint row headers:
    if (prcDirty->left < CELL_CX) {
        RECT rcClip = { 0, HEADER_CY, HEADER_CX, rcDirtyBody.bottom };
        CustomSetClip(hDC, &rcClip);

        for (row = rowMin; row <= rowMax; row++) {
            RECT rc;
            TCHAR pszBuffer[32];

            rc.left = 0;
            rc.top = HEADER_CY + row * CELL_CY - nPosVert;
            rc.right = HEADER_CX;
            rc.bottom = rc.top + CELL_CY;
            _sntprintf_s(pszBuffer, 32, _TRUNCATE, _T("Row %d"), row);
            CustomPaintCell(hDC, pszBuffer, &rc, hHeaderBrush);
        }
    }

    SetTextColor(hDC, NORMAL_TEXT_COLOR);

    // Paint body cells:
    CustomSetClip(hDC, &rcDirtyBody);

    for (row = rowMin; row <= rowMax; row++) {
        RECT rc;

        rc.top = HEADER_CY + row * CELL_CY - nPosVert;
        rc.bottom = rc.top + CELL_CY;

        for (col = colMin; col <= colMax; col++) {
            TCHAR pszBuffer[32];

            rc.left = HEADER_CX + col * CELL_CX - nPosHorz;
            rc.right = rc.left + CELL_CX;
            _sntprintf_s(pszBuffer, 32, _TRUNCATE, _T("[%d, %d]"), col, row);
            CustomPaintCell(hDC, pszBuffer, &rc, ((col + row) % 2 == 0 ? hNormalBrushA : hNormalBrushB));

            if (rc.right > prcDirty->right)
                break;
        }

        if (rc.bottom > prcDirty->bottom)
            break;
    }

    DeleteObject(hHeaderBrush);
    DeleteObject(hNormalBrushA);
    DeleteObject(hNormalBrushB);
}

// Lets distinguish "real nPage" and logical "nPage". 
// The former is the value describing the state of scrollbar and
// stored internally. We can get it with GetScrollInfo().
//
// The latter is how much we really want to scroll when scrolling
// up or down for a page.
static int
CustomLogicalPage(int nPage)
{
    if (nPage > 100) {
        // For larger pages, it is better if there is a little overlap
        // so user does not get lost.
        return nPage - SCROLL_STEP;
    }

    if (nPage < SCROLL_STEP) {
        // Even if control is so low it does not even have space for 
        // a single line, we still want to make scroll at least a little.
        return SCROLL_STEP;
    }

    // In other cases, lets respect the real value.
    return nPage;
}

// Perform the scrolling to the new location.
// (Ensures the newPos is in the allowed range between nMin and nMax so all 
// callers can be simplified in this regard.)
static void
CustomSetScrollPos(CustomData* pData, int nPos, BOOL isVertical)
{
    int scrollbarId = isVertical ? SB_VERT : SB_HORZ;
    int nOldPos;
    int dx, dy;
    RECT rcBody;

    nOldPos = GetScrollPos(pData->hwnd, scrollbarId);

    // Setup and refresh the toolbar:
    SetScrollPos(pData->hwnd, scrollbarId, nPos, TRUE);

    // Ensure the new pos is in the allowed range (between nin and nMax):
    nPos = GetScrollPos(pData->hwnd, scrollbarId);

    // Refresh client area:
    GetClientRect(pData->hwnd, &rcBody);
    if (isVertical) {
        dx = 0;
        dy = nOldPos - nPos;
        rcBody.top = HEADER_CY;
    } else {
        dx = nOldPos - nPos;
        dy = 0;
        rcBody.left = HEADER_CX;
    }
    ScrollWindowEx(pData->hwnd, dx, dy,
        &rcBody, &rcBody, NULL, NULL, SW_ERASE | SW_INVALIDATE);
}

// Handle VM_VSCROLL and VM_HSCROLL:
static void
CustomScroll(CustomData* pData, int iWhat, BOOL isVertical)
{
    int scrollbarId = isVertical ? SB_VERT : SB_HORZ;
    int nPos;
    SCROLLINFO si;

    si.cbSize = sizeof(SCROLLINFO);
    si.fMask = SIF_RANGE | SIF_PAGE | SIF_POS | SIF_TRACKPOS;
    GetScrollInfo(pData->hwnd, scrollbarId, &si);

    switch (iWhat) {
    case SB_TOP:            nPos = si.nMin; break;
    case SB_BOTTOM:         nPos = si.nMax; break;
    case SB_LINEUP:         nPos = si.nPos - SCROLL_STEP; break;
    case SB_LINEDOWN:       nPos = si.nPos + SCROLL_STEP; break;
    case SB_PAGEUP:         nPos = si.nPos - CustomLogicalPage(si.nPage); break;
    case SB_PAGEDOWN:       nPos = si.nPos + CustomLogicalPage(si.nPage); break;
    case SB_THUMBTRACK:     nPos = si.nTrackPos; break;
    default:
    case SB_THUMBPOSITION:  nPos = si.nPos; break;
    }

    CustomSetScrollPos(pData, nPos, isVertical);
}

// Handle WM_MOUSEWHEEL and WM_MOUSEHWHEEL:
static void
CustomMouseWheel(CustomData* pData, int iDelta, BOOL isVertical)
{
    int scrollbarId = isVertical ? SB_VERT : SB_HORZ;
    SCROLLINFO si;
    int iLines;

    si.cbSize = sizeof(SCROLLINFO);
    si.fMask = SIF_PAGE | SIF_POS;
    GetScrollInfo(pData->hwnd, scrollbarId, &si);

    // Compute how many lines to scroll.
    iLines = WheelScrollLines(pData->hwnd, iDelta * SCROLL_STEP,
        CustomLogicalPage(si.nPage), isVertical);

    // Scroll to the desired location.
    CustomSetScrollPos(pData, si.nPos + iLines, isVertical);
}

// Handle WM_KEYDOWN message.
static void
CustomKeyDown(CustomData* pData, UINT vkCode)
{
    BOOL isShiftPressed = (GetKeyState(VK_SHIFT) & 0x8000);

    switch (vkCode) {
    case VK_HOME:   CustomScroll(pData, SB_TOP, !isShiftPressed); break;
    case VK_END:    CustomScroll(pData, SB_BOTTOM, !isShiftPressed); break;
    case VK_PRIOR:  CustomScroll(pData, SB_PAGEUP, !isShiftPressed); break;
    case VK_NEXT:   CustomScroll(pData, SB_PAGEDOWN, !isShiftPressed); break;
    case VK_UP:     CustomScroll(pData, SB_LINEUP, TRUE); break;
    case VK_DOWN:   CustomScroll(pData, SB_LINEDOWN, TRUE); break;
    case VK_LEFT:   CustomScroll(pData, SB_LINELEFT, FALSE); break;
    case VK_RIGHT:  CustomScroll(pData, SB_LINERIGHT, FALSE); break;
    }
}

// Control window procedure.
static LRESULT CALLBACK
CustomProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    CustomData* pData = (CustomData*) GetWindowLongPtr(hwnd, 0);

    switch(uMsg) {
        case XXM_SETCOLRANGE:
            return CustomSetColRange(pData, wParam, lParam);

        case XXM_SETROWRANGE:
            return CustomSetRowRange(pData, wParam, lParam);

        case WM_ERASEBKGND:
            return FALSE;  // Defer erasing into WM_PAINT

        case WM_PAINT:
        {
            PAINTSTRUCT ps;
            BeginPaint(hwnd, &ps);
            CustomPaint(pData, ps.hdc, &ps.rcPaint, ps.fErase);
            EndPaint(hwnd, &ps);
            return 0;
        }

        case WM_PRINTCLIENT:
        {
            RECT rc;
            GetClientRect(hwnd, &rc);
            CustomPaint(pData, (HDC) wParam, &rc, TRUE);
            return 0;
        }

        case WM_KEYDOWN:
            CustomKeyDown(pData, wParam);
            return 0;

        case WM_GETDLGCODE:
            return DLGC_WANTARROWS;

        case WM_VSCROLL:
        case WM_HSCROLL:
            CustomScroll(pData, LOWORD(wParam), (uMsg == WM_VSCROLL));
            return 0;

        case WM_MOUSEWHEEL:
        case WM_MOUSEHWHEEL:
            CustomMouseWheel(pData, (SHORT)HIWORD(wParam), (uMsg == WM_MOUSEWHEEL));
            return 0;

        case WM_LBUTTONDOWN:
            SetFocus(hwnd);
            break;

        case WM_SIZE:
            CustomSize(pData, LOWORD(lParam), HIWORD(lParam));
            return 0;

        case WM_SETFONT:
            pData->hFont = (HFONT)wParam;
            if (lParam)
                InvalidateRect(hwnd, NULL, TRUE);
            return 0;

        case WM_NCCREATE:
            pData = (CustomData*) malloc(sizeof(CustomData));
            if(pData == NULL)
                return FALSE;
            ZeroMemory(pData, sizeof(CustomData));
            SetWindowLongPtr(hwnd, 0, (LONG_PTR)pData);
            pData->hwnd = hwnd;
            CustomSetColRange(pData, 0, 5);
            CustomSetRowRange(pData, 0, 5);
            return TRUE;

        case WM_NCDESTROY:
            if(pData != NULL)
                free(pData);
            return 0;
    }
    return DefWindowProc(hwnd, uMsg, wParam, lParam);
}

void
CustomRegister(HINSTANCE hInstance)
{
    WNDCLASS wc = { 0 };

    wc.hInstance = hInstance;
    wc.lpfnWndProc = CustomProc;
    wc.cbWndExtra = sizeof(CustomData*);
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.lpszClassName = CUSTOM_WC;
    RegisterClass(&wc);
}

void
CustomUnregister(void)
{
    UnregisterClass(CUSTOM_WC, NULL);
}
