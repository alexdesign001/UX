/* File resource.h
 * (resource IDs)
 */

#ifndef RESOURCE_H
#define RESOURCE_H


/* Main dialog ID */
#define IDD_MAIN      100

#define ID_CUSTOM     200
#define ID_REAL       201


#endif  /* RESOURCE_H */
