﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="App.xaml.cs" company="saramgsilva">
//   Copyright (c) 2014 saramgsilva. All rights reserved.
// </copyright>
// <summary>
//   Interaction logic for App.xaml.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace ModernUIDForWPFSample.BlankWindow
{
    /// <summary>
    /// Interaction logic for App.xaml.
    /// </summary>
    public partial class App
    {
    }
}
